import { useState } from "react"
import Nav from "./Nav"
import NavItem from "./NavItem"

// import  data from '../data.json';
const { Link } = require("react-router-dom")



const MainNavigation = () => {
    
    const [isActive,setActive] = useState("");
    
    const activeHandler =(e,item)=>{
        // setActive(!i);
        e.preventDefault();
        console.log(e.target);
        console.log(e.target.text, "",item.name);
        if(e.target.text === item.name){
            setActive(item.name);
            // item.isActive = !item.isActive
        }
        else{
            setActive(false)
        }
        
        console.log(isActive, item.isActive);

        
    
    }
    const navigation = [
        { name: 'Home', to: "/", current: true, },
        { name: 'About', to: "/about", current: false },
        { name: 'Products', to: '/products', current: true },
        // { name: 'Profile', to: '#', current: false },
    ]
    console.log(navigation);
    return  <>
    <div className="bg-green-700  h-16  ">
       
       <Nav >
       {navigation.map((item) => (
                <NavItem
                    key={item.name}
                    to={item.to}
                    isActive={isActive}
                    onClick={(e) =>  activeHandler(e,item)}
                    className='text-white mt-3 hover:rounded-mx-1 px-4 py-2 text-lm font-large '
                >
                    {item.name}
                </NavItem>
            ))}
        </Nav>
    </div>
    <br></br>
    <div className="bg-green-700    ">
            
        </div>
    </>

}
export default MainNavigation;
