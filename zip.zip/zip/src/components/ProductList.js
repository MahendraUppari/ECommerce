import pic from '../assets/white_tee_edite.jpg';
import pic1 from '../assets/white_tee_men.jpg';
import pic2 from '../assets/Black_full_sleeve.jpg';
import pic3 from '../assets/Grey_Tee_Polo.jpg';
import jeans1 from '../assets/Blue_jeans.JPG';
import jeans2 from '../assets/low_rise_beige_jeans.JPG';
import jeans3 from '../assets/light_blue_ripped_denim.JPG';
import jeans4 from '../assets/Black_jeans.JPG';
import jeans5 from '../assets/Jogger_jeans.JPG';

const products = [
    
    {
        id: 1,
        name: 'Basic Tee',
        href: '#',
        price: 500,
        imageSrc: pic1,
        imageAlt: 'Tall slender porcelain bottle with natural clay textured body and cork stopper.',
        color: 'White',
      },
      {
        id: 2,
        name: 'Full Sleeve Tee',
        href: '#',
        price: 650,
        imageSrc: pic2,
        color: 'Black',
        imageAlt: 'Olive drab green insulated bottle with flared screw lid and flat top.',
      },
      {
        id: 3,
        name: 'Polo Tees',
        href: '#',
        price: 600,
        imageSrc: pic3,
        color:'Grey',
        imageAlt: 'Person using a pen to cross a task off a productivity paper card.',
      },
      {
        id: 4,
        name: 'Casual Jeans',
        href: '#',
        price: 999,
        imageSrc: jeans1,
        color:'Blue',
        imageAlt: 'Hand holding black machined steel mechanical pencil with brass tip and top.',
      },
      {
        id: 5,
        name: 'Low rise Jeans',
        href: '#',
        price: 1099,
        imageSrc: jeans2,
        color:'Beige',
        imageAlt: 'Hand holding black machined steel mechanical pencil with brass tip and top.',
      },
      {
        id: 6,
        name: 'Lightly Washed Jeans',
        href: '#',
        price: 899,
        imageSrc: jeans4,
        color:'Black',
        imageAlt: 'Hand holding black machined steel mechanical pencil with brass tip and top.',
      },
      {
        id: 7,
        name: 'Distressed Jeans',
        href: '#',
        price: 1899,
        color:"Light blue",
        imageSrc: jeans3,
        imageAlt: 'Hand holding black machined steel mechanical pencil with brass tip and top.',
      },
      {
        id: 8,
        name: 'Jogger Jeans',
        href: '#',
        price: 1799,
        color:"Black",
        imageSrc: jeans5,
        imageAlt: 'Hand holding black machined steel mechanical pencil with brass tip and top.',
      },
      {
        id: 0,
        name: 'Basic Tee',
        href: '#',
        price: 799,
        imageSrc: pic ,
        imageAlt: "Front of women's Basic Tee in white.",
        color: 'Faded white',
      },
    // More products...
  ]
const ProductList = () =>{
    return <>
    <div className="bg-white ">
      <div className=" mx-auto max-w-2xl  px-4 sm:py-2 sm:px-6 lg:max-w-7xl lg:px-8">
        <h2 className="text-2xl font-bold tracking-tight text-gray-900">All Products</h2>

        <div className="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          {products.map((product) => (
            <div key={product.id} className="group relative">
              <div className="min-h-80 aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-md bg-gray-200 group-hover:opacity-75 lg:aspect-none lg:h-80">
                <img
                  src={product.imageSrc}
                  alt={product.imageAlt}
                  className="h-full w-full object-cover object-center lg:h-full lg:w-full"
                />
              </div>
              <div className="mt-4 flex justify-between">
                <div>
                  <h3 className="text-sm text-gray-700">
                    <a href={product.href}>
                      <span aria-hidden="true" className="absolute inset-0" />
                      {product.name}
                    </a>
                  </h3>
                  <p className="mt-1 text-sm text-gray-500">{product.color}</p>
                </div>
                <p className="text-sm font-medium text-gray-900">INR {product.price}/-</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
    </>
}
export default ProductList;