import { useState } from "react"
import Nav from "./Nav"
import NavItem from "./NavItem"

// import  data from '../data.json';
const { Link } = require("react-router-dom")



const MainNavigation = () => {
    
    const [isActive,setActive] = useState("");
    
    const activeHandler =(e,item)=>{
        e.preventDefault();
        
        if(e.target.text === item.name){
            setActive(item.name);
        }
        else{
            setActive(false)
        }
        
    }
    const navigation = [
        { name: 'Home', to: "/", current: true, },
        { name: 'About', to: "/about", current: false },
        { name: 'Products', to: '/products', current: true },
        { name: 'Profile', to: '/auth', current: true },
        // { name: 'Profile', to: '#', current: false },
    ]
    console.log(navigation);
    return  <div className=" bg-green-700 flex justify-between">
    <div className="rounded-mx-2 mx-14 mt-4">
            <button className="hidden w-full 
            lg:flex items-center text-sm leading-6 text-slate-400 rounded-md ring-1 ring-slate-900/10 
            shadow-sm py-1.5 pl-2 pr-3 hover:ring-slate-300 
">
            <svg width="24" height="24" fill="none" aria-hidden="true" class="mr-3 flex-none">
                <path d="m19 19-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" 
                stroke-linejoin="round"></path><circle cx="11" cy="11" r="6" stroke="currentColor"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></circle></svg>
            <input type="text" className="h-9 mt-4  p-5 " 
            className="ml-auto pl-3 flex-none text-xs font-semibold border_radius10"/>
            </button>
       </div>
       
    <div className="  h-16   ">
        <Nav >
       {navigation.map((item) => (
                <NavItem
                    key={item.name}
                    to={item.to}
                    name={item.name}
                    // isActive={isActive}
                    // onClick={(e) =>  activeHandler(e,item)}
                    className='text-white mt-3 hover:rounded-mx-1 px-4 py-2 text-lm font-large '
                >
                    {item.name}
                </NavItem>
            ))}
        </Nav>
    </div>
    </div>

}
export default MainNavigation;
