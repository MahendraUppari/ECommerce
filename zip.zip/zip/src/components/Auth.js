// import { useOktaAuth } from "@okta/okta-react/bundles/types";
// import { useOktaAuth } from "@okta/okta-react/bundles/types";
// import { useOktaAuth } from "../../node_modules/@okta/okta-react/bundles/types";
import { useRef, useState } from "react";

import {oktaAuth} from '../config';

const Auth = () =>{
    
    // const { oktaAuth } = useOktaAuth();
    const [sessionToken, setSessionToken] = useState('');
  
    const submitHandler = (event) =>{
        event.preventDefault()
        console.log(userName.current.value);
        console.log(password.current.value , email_address.current.value);
        const data = {
            username: email_address.current.value,
            password: password.current.value,
          };
        oktaAuth.signInWithCredentials(data)
        .then((res) => {
          const sessionToken = res.sessionToken;
          console.log("Success ",res);
          if (!sessionToken) {
            throw new Error("authentication process failed");
          }
          setSessionToken(sessionToken);
        //   oktaAuth.signInWithRedirect({
        //     originalUri: "/products",
        //     // @ts-ignore
        //     sessionToken: sessionToken,
        //   });
        })
        .catch((err) => console.log("handle error here", err));
    // };
    }

    const userName = useRef('');
    const password = useRef('');

    const email_address = useRef('');
    return <>

        <form className="bg-red-700">
            <h3>Login</h3>
            <div className="p-2">
                <label className="text-white ">User Name: </label>
                <input ref={userName} type="text" className=" mt-2"/>
                
            </div>
            <div className="p-2">
            <label className="text-white ">Mail Address: </label>
                <input ref={email_address} type="email"/>
            </div>
            <div className="p-2">
            <label className="text-white ">Password: </label>
                <input type="password" ref={password}/>
            </div>
            <button onClick={submitHandler}>Submit</button>
        </form>
    </>
}
export default Auth;