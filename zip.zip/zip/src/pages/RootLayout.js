import classes from './RootLayout.module.css';

const { Outlet } = require("react-router-dom")
const { default: MainNavigation } = require("../components/MainNavigation")

const RootLayoutPage = () =>{
    return <>

        <MainNavigation/>
        <main className={classes.content}>
            <Outlet></Outlet>
        </main>
    </>

} 
export default RootLayoutPage;