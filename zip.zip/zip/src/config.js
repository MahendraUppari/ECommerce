import OktaAuth from "@okta/okta-auth-js";

export const oktaAuth = new OktaAuth({
    issuer: 'https://dev-10308766.okta.com/oauth2/default',
    clientId: '0oa8kxtkzx2aEmN6d5d7',
    redirectUri: window.location.origin + '/login/callback'
  });


// export default oktaAuth;