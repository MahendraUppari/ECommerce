import { useState } from "react";
import { Link } from "react-router-dom";

const NavItem= (props) =>{

       const [isActive,setActive] = useState(false);

    const activeHandler =()=>{
        console.log(isActive);
        setActive(!isActive);
        
        console.log(isActive);
    }
    return <>
        <li>
            <Link to={props.to}        
                onClick={props.onClick}
             className={`block px-3 py-2 rounded-md ${props.isActive === props.children ? 'bg-green-500 text-white' : 'bg-slate-50'}`}
                >{props.children}</Link>      
        </li>
        
    </>
}
export default NavItem;