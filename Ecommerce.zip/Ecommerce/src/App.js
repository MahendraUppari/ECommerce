import { createBrowserRouter , RouterProvider} from 'react-router-dom';
import logo from './logo.svg';
import './App.css';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import RootLayoutPage from './pages/RootLayout';
import ProductList from './components/ProductList';

const router = createBrowserRouter([
  {path:'/',
  element:<RootLayoutPage></RootLayoutPage>,
  children:[
    {path:'/',element:<HomePage></HomePage>},
    {path:'/about',element:<AboutPage></AboutPage>},
    {path:'/products',element:<ProductList/>},
  
  ]
}  
])
function App() {
  return <RouterProvider router={router}/>
}

export default App;
