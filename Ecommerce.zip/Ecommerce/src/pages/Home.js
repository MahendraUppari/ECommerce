import '../../src/index.css'
const HomePage =() =>{
    return <h1 className="text-xl font-bold underline">
    Hello world!
  </h1>

}

export default HomePage;  