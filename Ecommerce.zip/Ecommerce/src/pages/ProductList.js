import ProductList from "../components/ProductList";

const ProductList = () =>{
    return <ProductList/>
}
export default ProductList;