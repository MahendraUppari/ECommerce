const { Link } = require("react-router-dom")

const navigation = [
    { name: 'Home', to: "/", current: true },
    { name: 'About', to: "/about", current: false },
    // { name: 'Cart', to: '#', current: false },
    // { name: 'Profile', to: '#', current: false },
]


const MainNavigation = () => {
    return <div className="bg-green-700 h-16 flex justify-end sticky top-0 ">

            {navigation.map((item) => (
                <Link
                    key={item.name}
                    to={item.to}
                    className='text-white mt-3 hover:rounded-mx-1 px-4 py-2 text-lm font-large '

                    aria-current={item.current ? 'page' : undefined}
                >
                    {item.name}
                </Link>
            ))}
            <ul className="flex">
            <li className=' text-white  mt-3 px-4 py-2 text-lm font-large cursor-pointer'>
                    Wishlist
                        </li>
                <li className=' text-white hover:rounded-mb-1  mt-3 px-4 py-2 text-lm font-large cursor-pointer'>
                    Cart
                        </li>
                <li className=' text-white mt-3  px-4 py-2 text-lm font-large cursor-pointer'>
                    Profile
                        </li>
            </ul>
            
        </div>

    {/* </div> */}

}
export default MainNavigation;
